# Essai Expo Icon Assets

This folder contains Expo/mobile icon assets generated from the finalized SVG sources.

## Source Mapping

- Normal app-level icon assets are generated from `../padded-reversed.svg`.
- Android adaptive foreground assets are generated from `../padded.svg`, recolored to white or black.
- Expo web favicon is generated from `../pure.svg`.

## Directory Structure

### `common/icon.png`

- Size: 1024x1024 PNG.
- Source: `padded-reversed.svg`.
- Intended Expo config: `expo.icon`.
- Use when one shared icon should cover iOS and Android legacy fallback.

### `ios/icon.png`

- Size: 1024x1024 PNG.
- Source: `padded-reversed.svg`.
- Intended Expo config: `expo.ios.icon` if we want iOS to be explicit.
- Used by iOS/iPadOS app icon surfaces in standalone builds, development builds, TestFlight, and App Store flows.
- Do not add rounded corners manually; the system applies its own mask.

### `android/legacy/icon.png`

- Size: 1024x1024 PNG.
- Source: `padded-reversed.svg`.
- Intended Expo config: `expo.android.icon` if we want Android legacy fallback to be explicit.
- Used as Android's non-adaptive / fallback app icon path.

### `android/adaptive/foreground.png`

- Size: 1024x1024 PNG.
- Source: `padded.svg`, recolored white, transparent background.
- Intended Expo config: `expo.android.adaptiveIcon.foregroundImage`.
- Used by Android adaptive launcher icons together with a background color or image.

### `android/adaptive/background.png`

- Size: 1024x1024 PNG.
- Solid brand background `#C8AE8B`.
- Optional intended Expo config: `expo.android.adaptiveIcon.backgroundImage`.
- Usually `backgroundColor: "#C8AE8B"` is enough, so this file is mainly for inspection or future use.

### `android/adaptive/monochrome.png`

- Size: 1024x1024 PNG.
- Source: `padded.svg`, recolored black, transparent background.
- Intended Expo config: `expo.android.adaptiveIcon.monochromeImage`.
- Used by Android 13+ themed icons when enabled by the user.

### `web/favicon.png`

- Size: 48x48 PNG.
- Source: `pure.svg`.
- Intended Expo config: `expo.web.favicon`.
- Only applies if the Expo mobile package is also built for web. This is separate from the Next.js web app icons.

### `preview/`

- Contains small preview PNGs and `index.html` for quick visual inspection.
- Not intended to be committed into the app.

## Suggested `app.json` Shape

```json
{
  "expo": {
    "icon": "./assets/icon.png",
    "ios": {
      "icon": "./assets/ios/icon.png"
    },
    "android": {
      "icon": "./assets/android/legacy/icon.png",
      "adaptiveIcon": {
        "foregroundImage": "./assets/android/adaptive/foreground.png",
        "backgroundColor": "#C8AE8B",
        "monochromeImage": "./assets/android/adaptive/monochrome.png"
      }
    },
    "web": {
      "favicon": "./assets/web/favicon.png"
    }
  }
}
```

Actual paths can be simplified when we move the files into `packages/mobile/assets`.

## Notes

Expo Go itself keeps the Expo Go launcher icon. These assets affect standalone builds, EAS development builds, preview builds, production builds, and the project icon shown inside Expo surfaces where supported.
