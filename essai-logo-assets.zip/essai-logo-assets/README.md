# Essai Logo Assets

This folder contains finalized source-level logo assets and generated web icon assets.

## Final Source Files

- `pure.svg`
  - Tight transparent logo mark.
  - Source for favicon/tab icons and any tiny surface where the mark should look visually full.

- `padded.svg`
  - Transparent logo mark with app-style breathing room.
  - Reserved for transparent padded use cases, such as Android adaptive foreground work.

- `padded-reversed.svg`
  - Solid brand background with a white logo mark.
  - Main source for app-level icons, Apple Touch Icon, and PWA/home-screen icons.

- `padded-reversed-cutout.svg`
  - Solid brand background with the logo cut out as transparent space.
  - Reserved for a knockout/cutout visual direction.

- `web/`
  - Generated web-ready icon files.

- `deprecated/`
  - Previous generated variants and tracking files. Keep for reference only.

## Web Icon Files

### Browser tab / favicon

Use the pure source.

- `web/icon.svg`
  - Copy from `pure.svg`.
  - For Next.js App Router, place at `packages/web/src/app/icon.svg`.
  - Used by modern browsers for tab/favicon-like surfaces.

- `web/favicon.ico`
  - Generated from the pure source.
  - For Next.js App Router, place at `packages/web/src/app/favicon.ico`.
  - Legacy compatibility fallback for browser tab/favicon surfaces.

- `web/favicon-16x16.png` and `web/favicon-32x32.png`
  - Generated from the pure source.
  - Optional explicit small PNG favicon assets. Keep if a manifest or manual metadata setup needs them.

### Mobile browser home-screen / PWA icons

Use the padded reversed source.

- `web/apple-icon.png`
  - Same image as `apple-touch-icon.png`, named for Next.js App Router.
  - Place at `packages/web/src/app/apple-icon.png`.

- `web/apple-touch-icon.png`
  - Standard Apple Touch Icon filename.
  - Use if we choose manual public-file metadata instead of the Next.js file convention.

- `web/android-chrome-192x192.png`
  - Rendered from `padded-reversed.svg`.
  - Place in `packages/web/public/` if referenced by `site.webmanifest`.

- `web/android-chrome-512x512.png`
  - Rendered from `padded-reversed.svg`.
  - Place in `packages/web/public/` if referenced by `site.webmanifest`.

- `web/site.webmanifest`
  - References the 192x192 and 512x512 PWA/home-screen icons.
  - Place in `packages/web/public/` or convert to a Next.js `manifest.ts` later.

## Current Web Placement Plan

When wiring into the web app:

- `web/favicon.ico` -> `packages/web/src/app/favicon.ico`
- `web/icon.svg` -> `packages/web/src/app/icon.svg`
- `web/apple-icon.png` -> `packages/web/src/app/apple-icon.png`
- `web/android-chrome-192x192.png` -> `packages/web/public/android-chrome-192x192.png`
- `web/android-chrome-512x512.png` -> `packages/web/public/android-chrome-512x512.png`
- `web/site.webmanifest` -> `packages/web/public/site.webmanifest`
